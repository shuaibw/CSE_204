public class LinkedStack<Item> {
    SLL<Item> list = new SLL<>();

    public LinkedStack() {
    }

    public void push(Item item) {
        list.addLast(item);
    }

    public Item pop() {
        return list.removeLast();
    }

    public int size() {
        return list.size();
    }

    public Item peek() {
        return list.peekLast();
    }

    public boolean isEmpty() {
        return list.isEmpty();
    }

    public String[] toArray() {
        return list.toArray();
    }
}
