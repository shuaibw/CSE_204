import java.util.Arrays;
import java.util.Iterator;

public class SLL<Item> implements Iterable<Item> {
    private class Node {

        Item item;
        Node next;
    }

    private Node first;

    private Node last;
    private int size;

    public SLL() {
    }

    public void addFirst(Item item) {
        if (item == null) throw new IllegalArgumentException("null items cannot be added to list");
        Node node = new Node();
        node.item = item;
        node.next = first;
        if (size == 0) last = node;
        first = node;
        size++;
    }

    public void addLast(Item item) {
        if (item == null) throw new IllegalArgumentException("null items cannot be added to list");
        Node node = new Node();
        node.item = item;
        if (size == 0) first = node;
        else last.next = node;
        last = node;
        size++;
    }

    public Item removeFirst() {
        if (size == 0) throw new UnsupportedOperationException("cannot delete from empty list");
        Item item = first.item;
        first = first.next;
        if (size == 1) last = null;
        size--;
        return item;
    }

    public Item removeLast() {
        if (size == 0) throw new UnsupportedOperationException("cannot delete from empty list");
        Item item = last.item;
        if (first == last) {
            first = last = null;
            size--;
            return item;
        }
        Node current = first;
        while (current.next != last) current = current.next;
        current.next = null;
        last = current;
        size--;
        return item;
    }

    public Item peekFirst() {
        if (size == 0) throw new UnsupportedOperationException("cannot peek from empty list");
        return first.item;
    }

    public Item peekLast() {
        if (size == 0) throw new UnsupportedOperationException("cannot peek from empty list");
        return last.item;
    }

    public void addBefore(int idx, Item item) {
        if (idx < 0 || idx >= size) throw new IllegalArgumentException("Index must be between 0 and size");
        Node node = new Node();
        node.item = item;
        Node current = first;
        for (int i = 0; i < idx - 1; i++) current = current.next;
        node.next = current.next;
        if (current == first) first = node;
        else current.next = node;
        size++;
    }

    public void addAfter(int idx, Item item) {
        if (idx < 0 || idx >= size) throw new IllegalArgumentException("Index must be between 0 and size");
        Node node = new Node();
        node.item = item;
        Node current = first;
        for (int i = 0; i < idx; i++) current = current.next;
        node.next = current.next;
        if (current == last) last = node;
        else current.next = node;
        size++;
    }

    public void remove(int idx) {
        if (idx < 0 || idx >= size) throw new IllegalArgumentException("Index must be between 0 and size");
        Node current = first;
        for (int i = 0; i < idx - 1; i++) current = current.next;
        if (current == first) first = null;
        else current.next = current.next.next;
        size--;
    }

    public int size() {
        return size;
    }

    public boolean isEmpty() {
        return size == 0;
    }

    @Override
    public Iterator<Item> iterator() {
        return new Iterator<>() {
            Node current = first;

            @Override
            public boolean hasNext() {
                return current != null;
            }

            @Override
            public Item next() {
                Item item = current.item;
                current = current.next;
                return item;
            }
        };
    }

    @Override
    public String toString() {
        String[] ara = new String[size];
        int idx = 0;
        for (Item item : this) {
            ara[idx++] = item.toString();
        }
        return Arrays.toString(ara);
    }

    public String[] toArray() {
        String[] ara = new String[size];
        int idx = 0;
        for (Item item : this) {
            ara[idx++] = item.toString();
        }
        return ara;
    }

    public static void main(String[] args) {
        SLL<Integer> sll = new SLL<>();
        sll.addLast(1);
        sll.addLast(2);
        sll.removeLast();
        sll.removeLast();
        System.out.println(sll);
    }

}
