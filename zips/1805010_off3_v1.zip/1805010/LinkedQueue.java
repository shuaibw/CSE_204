public class LinkedQueue<Item> {
    SLL<Item> sll = new SLL<>();

    public LinkedQueue() {

    }

    public void enqueue(Item item) {
        sll.addLast(item);
    }

    public Item dequeue() {
        return sll.removeFirst();
    }

    public int size() {
        return sll.size();
    }

    public Item peek() {
        return sll.peekFirst();
    }

    public boolean isEmpty() {
        return sll.isEmpty();
    }
}
