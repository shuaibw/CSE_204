public class PairOfPoints {
    Point p1, p2;
    int dist;

    public PairOfPoints(Point p1, Point p2, int dist) {
        this.p1 = p1;
        this.p2 = p2;
        this.dist = dist;
    }
}