//
// Created by Shuaib on 08-Jun-21.
//

#ifndef SORTINGOFF_APPLY_SORT_H
#define SORTINGOFF_APPLY_SORT_H


class apply_sort {
public:
    apply_sort() = delete;

    static void merge_sort(int ara[], int len) {
        int *aux = new int[len];
        do_merge_sort(ara, aux, 0, len - 1);
        delete[] aux;
    }

private:
    static void merge(int ara[], int aux[], int lo, int mid, int hi) {
        int i, j;
        for (i = lo; i <= hi; i++) aux[i] = ara[i];
        i = lo;
        j = mid + 1;
        for (int k = lo; k <= hi; k++) {
            if (i > mid) ara[k] = aux[j++];
            else if (j > hi) ara[k] = aux[i++];
            else if (aux[j] < aux[i]) ara[k] = aux[j++];
            else ara[k] = aux[i++];
        }
    }

    static bool isSorted(const int ara[], int from, int to) {
        if (from == to) return true;
        for (int i = from; i < to; i++) if (ara[i] > ara[i + 1]) return false;
        return true;
    }

    static void do_merge_sort(int ara[], int aux[], int lo, int hi) {
        if (hi <= lo) return;
        int mid = lo + (hi - lo) / 2;
        do_merge_sort(ara, aux, lo, mid);
        do_merge_sort(ara, aux, mid + 1, hi);
        merge(ara, aux, lo, mid, hi);
    }
};


#endif //SORTINGOFF_APPLY_SORT_H
