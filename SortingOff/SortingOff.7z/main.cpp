#include <random>
#include <iostream>
#include <memory>
#include <chrono>
#include "apply_sort.h"

using namespace std;
enum Order {
    ASC,
    DESC,
    RAND
};

bool isSorted(const int ara[], int len) {
    for (int i = 0; i < len - 1; i++) {
        if (ara[i] > ara[i + 1]) return false;
    }
    return true;
}

unsigned long long run_merge_run(int runs, int size, Order order) {
    default_random_engine gen(static_cast<long unsigned int>(time(nullptr)));
    uniform_int_distribution<> distrib(-1000000, 1000000);
    int beg = distrib(gen);
    auto times = make_unique<unsigned long long[]>(runs);
    for (int i = 0; i < runs; i++) {
        auto ara = make_unique<int[]>(size);
        if (order == RAND)
            for (int n = 0; n < size; ++n) ara[n] = distrib(gen);
        else if (order == ASC)
            for (int n = 0; n < size; ++n) ara[n] = beg++;
        else
            for (int n = 0; n < size; ++n) ara[n] = beg--;
        auto start = chrono::high_resolution_clock::now();
        apply_sort::merge_sort(ara.get(), size);
        auto stop = chrono::high_resolution_clock::now();
        if (!isSorted(ara.get(), size)) return -1;
        auto duration = chrono::duration_cast<chrono::nanoseconds>(stop - start);
        times[i] = duration.count();
//        cout << "Run " << i << '\n';
//        for (int i = 0; i < size; i++) cout << ara[i] << '\n';
//        cout << (isSorted(ara.get(), size) ? "YES" : "NO") << '\n';
    }
    unsigned long long sum = 0;
    for (int i = 0; i < runs; i++) sum += times[i];
//    cout << (double) sum / (1000000 * runs) << '\n';
    return sum;
}

int main() {
    const int runs = 50;
    cout << "Statistics for randomly generated numbers" << '\n';
    for (int i = 10; i < 10000001; i *= 10) {
        unsigned long long tot_time = run_merge_run(runs, i, RAND);
        cout << "n = " << i << " : " << static_cast<double>(tot_time) / (1000000 * runs) << " ms" << '\n';
    }
}